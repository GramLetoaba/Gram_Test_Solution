﻿
class Account
{
    // Private constructor to prevent instantiation
    private Account() { }

    // Properties
    public string ClientNumber { get; set; }
    public string AccountNumber { get; set; }
    public decimal Balance { get; set; }

    // Method to print details
    public virtual void PrintDetails()
    {
        Console.WriteLine($"Client Number: {ClientNumber}");
        Console.WriteLine($"Account Number: {AccountNumber}");
        Console.WriteLine($"Balance: {Balance:C}");
    }
}

class IndividualAccount : Account
{
    // Properties
    public string FirstName { get; set; }
    public string Surname { get; set; }
    public string IdNumber { get; set; }

    // Override PrintDetails
    public override void PrintDetails()
    {
        // Call base class method
        base.PrintDetails();

        // Print additional details
        Console.WriteLine($"First Name: {FirstName}");
        Console.WriteLine($"Surname: {Surname}");
        Console.WriteLine($"ID Number: {IdNumber}");
    }
}

class CorporateAccount : Account
{
    // Properties
    public string CompanyName { get; set; }
    public string CompanyRegNo { get; set; }

    // Override PrintDetails
    public override void PrintDetails()
    {
        // Call base class method
        base.PrintDetails();

        // Print additional details
        Console.WriteLine($"Company Name: {CompanyName}");
        Console.WriteLine($"Company Registration Number: {CompanyRegNo}");
    }
}

class Program
{
    static void Main()
    {
        // Instantiate IndividualAccount and set properties
        IndividualAccount individualAccount = new IndividualAccount
        {
            ClientNumber = "IND123",
            AccountNumber = "INDACC001",
            Balance = 1000.50m,
            FirstName = "John",
            Surname = "Doe",
            IdNumber = "1234567890123"
        };

        // Instantiate CorporateAccount and set properties
        CorporateAccount corporateAccount = new CorporateAccount
        {
            ClientNumber = "CORP456",
            AccountNumber = "CORPACC001",
            Balance = 50000.75m,
            CompanyName = "ABC Corp",
            CompanyRegNo = "123456789"
        };

        // Create a list to hold both account types
        List<Account> accountList = new List<Account>
        {
            individualAccount,
            corporateAccount
        };

        // Loop through the list and call the PrintDetails() method
        foreach (var account in accountList)
        {
            Console.WriteLine("Account Details:");
            account.PrintDetails();
            Console.WriteLine(); // Add a line break between accounts
        }
    }
}
