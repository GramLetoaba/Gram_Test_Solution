﻿Find and Fix the 3 bugs in the program.

1. The first bug is a compilation error.
2. The second bug is a runtime error.
3. The third bug is a logic error