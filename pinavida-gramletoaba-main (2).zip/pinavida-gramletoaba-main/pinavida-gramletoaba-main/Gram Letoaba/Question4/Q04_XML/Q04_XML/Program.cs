﻿
using System.Xml.Linq;

namespace Q04_XML
{
    class Program
    {
        static void Main(string[] args)
        {
            PopulateData();
        }

        //This function must list all the character Names and their Age
        //Use the sample.xml file in this project to get the information
        //Final result must be 4 rows/lines
        // Example Row Format: Name (Age)
        private static void PopulateData()
        {
            try
            {
                //Load XML into string
                XDocument xml = XDocument.Load("sample.xml");

                // Query the XML to get character names and ages
                var characters = from character in xml.Descendants("character")
                                    select new
                                    {
                                        Name = character.Element("name")?.Value,
                                        Born = character.Element("born")?.Value
                                    };

                // Display the result
                foreach (var character in characters)
                {
                    if (!string.IsNullOrEmpty(character.Name) && !string.IsNullOrEmpty(character.Born))
                    {
                        Console.WriteLine($"{character.Name} ({CalculateAge(character.Born)})");
                    }
                }

                Console.ReadKey();

            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred when reading xml file: {ex.Message}");
            }
        }

        static int CalculateAge(string birthDate)
        {
            // Assuming the birth date is in the format "yyyy-MM-dd"
            DateTime birthDateTime = DateTime.Parse(birthDate);
            DateTime today = DateTime.Today;

            int age = today.Year - birthDateTime.Year;

            // Check if the birthday has occurred this year
            if (birthDateTime > today.AddYears(-age))
            {
                age--;
            }

            return age;
        }
    }
}