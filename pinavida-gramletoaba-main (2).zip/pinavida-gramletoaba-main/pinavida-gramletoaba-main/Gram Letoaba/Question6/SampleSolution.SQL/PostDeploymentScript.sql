-- Customers table
CREATE TABLE Customers (
    CustomerId INT PRIMARY KEY IDENTITY(1,1),
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    IdNumber VARCHAR(13) UNIQUE
);

-- Cars table
CREATE TABLE Cars (
    CarId INT PRIMARY KEY IDENTITY(1,1),
    Model VARCHAR(50),
    RetailValue DECIMAL(10, 2),
    DateManufactured INT,
    TopSpeed INT
);

-- CustomerCars joining table
CREATE TABLE CustomerCars (
    CustomerId INT,
    CarId INT,
    PRIMARY KEY (CustomerId, CarId)
);

-- Create a foreign key relationship between Customers and CustomerCars
ALTER TABLE CustomerCars
ADD FOREIGN KEY (CustomerId) REFERENCES Customers(CustomerId);

-- Create a foreign key relationship between Cars and CustomerCars
ALTER TABLE CustomerCars
ADD FOREIGN KEY (CarId) REFERENCES Cars(CarId);

-- Insert data into Customers
INSERT INTO Customers (FirstName, LastName, IdNumber)
VALUES
    ('Johan', 'Goosen', '0201128517087'),
    ('Simon', 'Miles', '0202028604181'),
    ('Jones', 'Jack', '8012027238085'),
    ('David', 'Levey', '8807027796184'),
    ('Jack', 'Leo', '9205107945087');

-- Insert data into Cars
INSERT INTO Cars (Model, RetailValue, DateManufactured, TopSpeed)
VALUES
    ('Toyota Hilux', 799000, 2021, 179),
    ('BMW 123!', 910000, 2023, 210),
    ('Ford Ranger', 810000, 2022, 181),
    ('Toyota Carola', 35000, 1999, 130),
    ('Ford Figo', 433000, 2015, 164),
    ('Chevy Spark', 190000, 2011, 112),
    ('GWM Double CAB', 320000, 2018, 125);

-- Insert data into CustomerCars
INSERT INTO CustomerCars (CustomerId, CarId)
VALUES
    (1, 1), -- Johan owns Toyota Hilux
    (1, 2), -- Johan owns BMW 123!
    (2, 1), -- Simon owns Toyota Hilux
    (2, 5), -- Simon owns Ford Figo
    (2, 7), -- Simon owns GWM Double CAB
    (3, 3), -- Jones owns Ford Ranger
    (3, 5), -- Jones owns Ford Figo
    (3, 6), -- Jones owns Chevy Spark
    (4, 7), -- David owns GWM Double CAB
    (4, 4), -- David owns Toyota Carola
    (5, 6); -- Jack owns Chevy Spark

