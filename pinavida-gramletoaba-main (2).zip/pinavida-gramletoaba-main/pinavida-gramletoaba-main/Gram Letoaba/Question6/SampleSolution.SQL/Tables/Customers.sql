﻿CREATE TABLE [dbo].[Customers]
(
	[CustomersId] INT NOT NULL PRIMARY KEY,
	[FirstName] Varchar(250) NOT NULL,
	[LastName] VARCHAR(250) NOT NULL,
	[IdNumber] VARCHAR(250) NOT NULL,
	[XML] VARCHAR(MAX) NULL,
)
