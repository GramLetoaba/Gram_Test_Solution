﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using SampleSolutionWPF.View;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Xml.Serialization;

namespace SampleSolutionWPF.ViewModel
{
    public class CustomerCarsViewModel : ViewModelBase
    {
        public ObservableCollection<CustomerCar> CustomerCars { get; set; }
        public ObservableCollection<Customer> Customers { get; set; }
        public Customer SelectedCustomer { get; set; }

        public ICommand FetchCustomerCarsCommand { get; private set; }
        public ICommand ImportXmlCommand { get; private set; }

        // Constructor
        public CustomerCarsViewModel()
        {
            FetchCustomerCarsCommand = new RelayCommand(FetchCustomerCars);
            ImportXmlCommand = new RelayCommand(ImportXml);
            CustomerCars = new ObservableCollection<CustomerCar>();
            
        }

        private void FetchCustomerCars()
        {
            Customers = DatabaseService.GetCustomers(); // Populate ComboBox
        }

        private void ImportXml()
        {
            if (SelectedCustomer != null)
            {
                var databaseService = new DatabaseService();
                var customerCars = databaseService.GetCustomerCars(SelectedCustomer.CustomerId);

                // Create an XML file and serialize the data
                var serializer = new XmlSerializer(typeof(List<CustomerCar>));
                using (var stream = new StreamWriter("ExportedData.xml"))
                {
                    serializer.Serialize(stream, customerCars);
                }

                // Show a message or perform other actions if needed
                MessageBox.Show("Data exported to XML successfully.");
            }
        }
    }
}
