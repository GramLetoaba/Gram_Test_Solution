﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleSolutionWPF.ViewModel
{
    public class DatabaseService
    {
        public List<Customer> GetCustomers()
        {
            return new List<Customer>();
        }

        public List<Car> GetCars()
        {
            return new List<Car>();
        }

        public List<CustomerCar> GetCustomerCars(int customerId)
        {
            return new List<CustomerCar>();
        }
    }
}
