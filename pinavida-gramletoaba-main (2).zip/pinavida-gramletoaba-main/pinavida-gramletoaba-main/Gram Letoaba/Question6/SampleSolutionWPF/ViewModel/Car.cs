﻿namespace SampleSolutionWPF.ViewModel
{
    public class Car
    {
        public int CarId { get; set; }
        public string Model { get; set; }
        public decimal RetailValue { get; set; }
        public int DateManufactured { get; set; }
        public int TopSpeed { get; set; }
    }
}