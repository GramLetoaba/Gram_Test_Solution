﻿
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace SampleSolutionWPF.ViewModel
{
    public class CustomersViewModel : ViewModelBase
    {
        public ObservableCollection<Customer> Customers { get; set; }
        public ICommand FetchCustomersCommand { get; private set; }

        public CustomersViewModel()
        {
            FetchCustomersCommand = new RelayCommand(FetchCustomers);
            Customers = new ObservableCollection<Customer>();
        }

        private void FetchCustomers()
        {
            // Implement logic to fetch customers from the database
        }
    }
}
