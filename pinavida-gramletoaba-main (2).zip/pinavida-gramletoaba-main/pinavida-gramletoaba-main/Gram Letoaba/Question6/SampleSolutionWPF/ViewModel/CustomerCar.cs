﻿namespace SampleSolutionWPF.ViewModel
{
    public class CustomerCar
    {
        public int CustomerId { get; set; }
        public int CarId { get; set; }
    }
}