﻿

using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace SampleSolutionWPF.ViewModel
{
    public class CarsViewModel : ViewModelBase
    {
        public ObservableCollection<Car> Cars { get; set; }
        public ICommand FetchCarsCommand { get; private set; }

        // Constructor
        public CarsViewModel()
        {
            FetchCarsCommand = new RelayCommand(FetchCars);
            Cars = new ObservableCollection<Car>();
        }

        private void FetchCars()
        {
            // Implement logic to fetch cars from the database
        }
    }
}
