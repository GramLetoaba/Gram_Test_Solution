﻿namespace Q03_ProblemSolving
{
    class Program
    {
        public static void Main(string[] args)
        {
            var value1 = "38475634639";
            var value2 = "88475634639";
            var value3 = "82345";
            //Console.WriteLine("{0}: {1}", value1, IsValid(value1));
            //Console.WriteLine("{0}: {1}", value2, IsValid(value2));
            //Console.WriteLine("{0}: {1}", value3, IsValid(value3));
            //Console.ReadLine();

            string accountNumber = "82345";
            bool isValid = IsValid(accountNumber);

            if (isValid)
            {
                Console.WriteLine("The account number is valid.");
            }
            else
            {
                Console.WriteLine("The account number is not valid.");
            }
        }

        public static bool IsValid(string value)
        {
            // Check if the input is valid
            if (string.IsNullOrEmpty(value) || !IsAllNumbers(value))
            {
                return false;
            }

            // Perform checksum calculation using recursion
            string result = CalculateChecksum(value);

            // Check if the final digit matches the check digit
            return int.Parse(result) == int.Parse(result[^1].ToString());
        }

        static string CalculateChecksum(string value)
        {
            try
            {
                // Base case: if the length is 1, return the value
                if (value.Length == 1)
                {
                    return value;
                }

                int sum = 0;

                // Iterate through consecutive pairs of digits
                for (int i = 1; i < value.Length - 1; i++)
                {
                    sum += int.Parse(value[i].ToString());
                }

                // Append the least significant digit of the sum to the new number
                return CalculateChecksum((sum % 10).ToString() + value[value.Length - 1].ToString());
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        static bool IsAllNumbers(string str)
        {
            // Check if all characters in the string are digits
            foreach (char c in str)
            {
                if (!char.IsDigit(c))
                {
                    return false;
                }
            }
            return true;
        }
    }
}